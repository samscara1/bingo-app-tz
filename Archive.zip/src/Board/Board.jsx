import React from 'react'
import { nanoid } from 'nanoid'

import { useDispatch } from 'react-redux'
import { Square } from '../Square/Square'
import { getSquares } from '../helpers/getSquares'

import style from './style.module.scss'
import { addActiveNum } from '../store/ticketsSlice'

export const Board = ({ title, field, ticketId }) => {
  const dispatch = useDispatch()
  const getActiveNum = (num) => {
    dispatch(addActiveNum({title: num, field, ticketId}))
  } 
  return (
    <section className={style.board}>
      <h6 className={style.title}>{title}</h6>
      {
        getSquares(20).map((square) => {
          return <Square num={square} key={nanoid()} handleClick={getActiveNum}/>
        })
      }
    </section>
  )
}
