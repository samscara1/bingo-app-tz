import React, { useState } from 'react'
// import { useDispatch } from 'react-redux';
import cn from 'classnames';
// import { addActiveNum } from '../store/ticketsSlice';
// import { useDispatch } from 'react-redux';
// import { addActiveNum, removeActiveNum } from '../store/ticketsSlice';

import Style from './style.module.scss';

export const Square =  ({ num, handleClick}) => {
  const [isActive, setIsActive] = useState(false)

  const active = cn(Style.square, {
    [Style.active]: isActive
  })
  // if (isActive) {
  //   dispatch(removeActiveNum({title, field, ticketId}))
  // } else if (!isActive) {
  //   dispatch(addActiveNum({title, field, ticketId}))
  // }
  // const dispatch = useDispatch()
  // useEffect(() => {
  //   if (isActive) {
  //     dispatch(addActiveNum({title, field, ticketId}))
  //     setIsActive(true)
  //   } else  {
  //     dispatch(removeActiveNum({title, field, ticketId}))
  //     setIsActive(false)
  //   }
  // }, [])
  const handlePush = () => {
    // // console.log(isActive)
    // if (isActive) {
    //   dispatch(addActiveNum({title, field, ticketId}))
    //   setIsActive(false)
    // } else {
    //   dispatch(removeActiveNum({title, field, ticketId}))
    //   setIsActive(true)
    // }
    // console.log(isActive)

    // dispatch(manageActiveNum({title, field, ticketId, isActive}))
    setIsActive(!isActive)
    handleClick(num)
  }
  console.log(active)
  return (
    <button 
      type="button"
      onClick={handlePush}
      className={active}
    >
      {num}
    </button>
  )
}
