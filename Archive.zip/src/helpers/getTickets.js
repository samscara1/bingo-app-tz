import { nanoid } from 'nanoid';

export const getTickets = (num) => {
  const ticketArray = Array(num).fill(
    {
      id: nanoid(),
      fieldOne: [],
      fieldTwo: [],
      ticketCombinations: 0
    }
  )
  return ticketArray
}