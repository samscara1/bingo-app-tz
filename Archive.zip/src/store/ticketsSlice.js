import { createSlice, current } from '@reduxjs/toolkit'
import { nanoid } from 'nanoid'
import { getTickets } from '../helpers/getTickets'

const initialState = {
  editionsNum: 0,
  combinationsTotal: 0,
  tickets: getTickets(3)
}

export const ticketsSlice = createSlice({
  name: 'tickets',
  initialState,
  reducers: {
    addTicket(state) {
      state.tickets.push(
        {
          id: nanoid(),
          fieldOne: [],
          fieldTwo: [],
          TicketCombinations: 0
        }
      )
    },
    manageActiveNum (state, {payload}) {
      let currentTicketField = state.tickets.find(ticket => ticket.id === payload.ticketId)[payload.field]
      if (!currentTicketField) {
        currentTicketField = []
      }
      if (payload.isActive) {
        const filterdField = currentTicketField.filter(num => num !== payload.title)
        // eslint-disable-next-line no-param-reassign
        state.tickets.find(ticket => ticket.id === payload.ticketId)[payload.field] = filterdField
        console.log('active')
      } else {
        currentTicketField.push(payload.title)
        console.log('inactive')
      }
    },
    addActiveNum(state, {payload: {ticketId, field, title}}) {
      const currentTicket = state.tickets.find(({id}) => id === ticketId)
      if (currentTicket) {
        if (currentTicket[field].includes(title)) {
          const filteredField = currentTicket[field].filter(num => num !== title)
          // eslint-disable-next-line no-param-reassign
          state.tickets.find(({id}) => id === ticketId)[field] = filteredField
          console.log('if', current(state.tickets))
        } else {
          const test = state.tickets.find(({id}) => id === ticketId)[field]
          test.push(title)
          // eslint-disable-next-line no-param-reassign
          state.tickets.find(({id}) => id === ticketId)[field] = test
          console.log('else', current(state.tickets))

        }
      }
    },
    removeActiveNum({tickets}, {payload}) {
      // let currentTicketField = tickets.find(ticket => ticket.id === payload.ticketId)[payload.field]
      // if (!currentTicketField) {
      //   currentTicketField = []
      // }
      // currentTicketField = currentTicketField.filter(num => num !== payload.title)
      // tickets. = state.roundScore.filter((arrow) => arrow.id !== action.payload);
      // console.log(current(currentTicketField))
      // const filteredTicket = ticket.filter(num => num !== payload.title)
      // state.tickets.find(ticket => ticket.id === payload.ticketId)[payload.field] = filteredTicket
      // console.log(current(state.tickets).find(ticket => ticket.id === action.payload.ticketId)[action.payload.field])
      // eslint-disable-next-line no-param-reassign
      // state.editionsNum -=1
      console.log(tickets, payload)
    }
  }
})

export const { addTicket, removeTicket, addActiveNum, removeActiveNum, manageActiveNum } = ticketsSlice.actions

export default ticketsSlice.reducer